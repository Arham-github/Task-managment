const profile = require("./find.profile");
const updateProfile = require("./update.profile");

module.exports = {
  profile,
  updateProfile,
};
