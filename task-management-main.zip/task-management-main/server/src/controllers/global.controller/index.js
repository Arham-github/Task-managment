const notFoundHandler = require("./notFount");
const errorHandler = require("./errorHandler");

module.exports = {
  notFoundHandler,
  errorHandler,
};
